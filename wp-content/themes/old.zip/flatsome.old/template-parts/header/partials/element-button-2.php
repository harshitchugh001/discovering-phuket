<li class="html header-button-2">
	<div class="header-button">
	<?php 
		echo do_shortcode('[button text="'.flatsome_option('header_button_2').'" link="'.flatsome_option('header_button_2_link').'" target="'.flatsome_option('header_button_2_link_target').'" rel="'.get_theme_mod('header_button_2_link_rel').'" radius="'.flatsome_option('header_button_2_radius').'" size="'.flatsome_option('header_button_2_size').'" color="'.flatsome_option('header_button_2_color').'" depth="'.flatsome_option('header_button_2_depth').'"  depth_hover="'.flatsome_option('header_button_2_depth_hover').'" style="'.flatsome_option('header_button_2_style').'"]');
	?>
	</div>
</li>
